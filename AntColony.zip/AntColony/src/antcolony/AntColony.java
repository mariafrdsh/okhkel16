/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package antcolony;

/**
 *
 * @author Maria Firdausiah
 */
import Ants.TravelingSalesman;

import java.util.Scanner;


public class AntColony {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
            
           
       

            int ants    = 125;          // Number of ants to run per generation.
            int gen     = 100;          // Number of generations.
            double evap = 0.5;          // Evaporation rate of pheromones.
            int alpha   = 1;            // Impact of pheromones on decision making.
            int beta    = 5;            // Impact of distance on decision making.
            
            System.out.println("Ants per epoch:" + ants);
            System.out.println("Epochs: " + gen);
            System.out.println("Evaporation Rate: " + evap);
            System.out.println("Alpha (pheromone impact): " + alpha);
            System.out.println("Beta (distance impact):   " + beta);

            TravelingSalesman travelingSalesman = new TravelingSalesman(ants, gen, evap, alpha, beta);
            travelingSalesman.run();
        
        System.out.println("-------------------------COMPLETE--------------------------");
    }

   

    private static double getUserDouble (String msg) {
        double input;
        while (true) {
            Scanner sc = new Scanner(System.in);
            System.out.print(msg);

            if (sc.hasNextDouble()) {
                input = sc.nextDouble();

                if (input <= 0) {
                    System.out.println("Number must be positive.");
                } else {
                    break;
                }

            } else {
                System.out.println("Invalid input.");
            }
        }
        return input;
    }

    private static int getUserInt (String msg) {
        int input;
        while (true) {
            Scanner sc = new Scanner(System.in);
            System.out.print(msg);

            if (sc.hasNextInt()) {
                input = sc.nextInt();

                if (input <= 0) {
                    System.out.println("Number must be positive.");
                } else {
                    break;
                }

            } else {
                System.out.println("Invalid input.");
            }
        }
        return input;
}
    
}
